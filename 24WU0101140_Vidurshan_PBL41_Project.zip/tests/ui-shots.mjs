import { chromium } from "playwright";
import { spawn, execSync } from "child_process";
import fs from "fs";

const PORT = 4202, BASE = `http://localhost:${PORT}`;
fs.mkdirSync("tests/out", { recursive: true });
execSync("node server/seed.js", { env: { ...process.env, DB_FILE: "data/ui.db" }, stdio: "ignore" });
const srv = spawn("node", ["server/index.js"], { env: { ...process.env, PORT, DB_FILE: "data/ui.db", ALLOW_INSECURE_DEMO: "1" }, stdio: "ignore" });
await new Promise((r) => setTimeout(r, 1200));

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH });
const out = { checks: [], network: [] };
const ok = (name, pass, detail = "") => { out.checks.push({ name, pass, detail }); console.log(pass ? "PASS" : "FAIL", name, detail); };
const PW = { admin: "Admin@Pbl41", compliance: "Comply@Pbl41", support: "Support@Pbl41", viewer: "Viewer@Pbl41" };

async function newSession(role) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 640 } });
  const page = await ctx.newPage();
  page.on("response", async (r) => {
    const u = new URL(r.url());
    if (!u.pathname.startsWith("/api/")) return;
    let body = ""; try { body = await r.text(); } catch {}
    out.network.push({ role: out.currentRole, method: r.request().method(), path: u.pathname, status: r.status(), reqBody: (r.request().postData() || "").replace(/"password":"[^"]*"/, '"password":"********"'), body });
  });
  out.currentRole = role;
  await page.goto(BASE);
  return page;
}
const login = async (page, role) => {
  await page.fill('[data-testid="username"]', role); await page.fill('[data-testid="password"]', PW[role]);
  await page.click('[data-testid="login-btn"]'); await page.waitForSelector('[data-testid="customers-table"]');
};
const shot = (page, name, clip) => page.screenshot({ path: `tests/out/${name}.png`, clip: clip || { x: 0, y: 0, width: 1280, height: 560 } });

// ---- login page + wrong password ----
let p = await newSession("anonymous");
await shot(p, "ui_01_login", { x: 340, y: 60, width: 600, height: 420 });
await p.fill('[data-testid="username"]', "admin"); await p.fill('[data-testid="password"]', "wrong"); await p.click('[data-testid="login-btn"]');
await p.waitForSelector('[data-testid="login-error"]');
ok("Login with wrong password shows an error", (await p.textContent('[data-testid="login-error"]')).includes("Invalid"));
await p.context().close();

// ---- support: masked by default, reveal email, locked fields ----
p = await newSession("support"); await login(p, "support");
const domBefore = await p.content();
ok("Support: raw values are NOT in the page DOM before any reveal", !["ravi.kumar@gmail.com", "9876543210", "ABCDE1234F", "234567890123", "4111 1111 1111 1111"].some((v) => domBefore.includes(v)));
await shot(p, "ui_02_support_masked");
ok("Support: PAN, Aadhaar and card controls are locked (disabled)", await p.isDisabled('[data-testid="lock-pan-1"]') && await p.isDisabled('[data-testid="lock-aadhaar-1"]') && await p.isDisabled('[data-testid="lock-card_number-1"]'));
await p.click('[data-testid="eye-email-1"]'); await p.waitForSelector('[data-testid="hide-email-1"]');
await p.click('[data-testid="eye-phone-1"]'); await p.waitForSelector('[data-testid="hide-phone-1"]');
const emailShown = await p.textContent('[data-testid="val-email-1"]');
ok("Support: email revealed without a password", emailShown === "ravi.kumar@gmail.com", emailShown);
await shot(p, "ui_03_support_revealed");
await p.click('[data-testid="hide-email-1"]');
ok("Support: Hide button masks the value again immediately", (await p.textContent('[data-testid="val-email-1"]')) === "r****@gmail.com");
ok("Support: no Audit log tab for this role", (await p.locator('[data-testid="tab-audit"]').count()) === 0);
await p.context().close();

// ---- viewer: everything locked ----
p = await newSession("viewer"); await login(p, "viewer");
await shot(p, "ui_04_viewer_locked");
ok("Viewer: all 40 sensitive cells are locked", (await p.locator('button.locked').count()) === 40, String(await p.locator('button.locked').count()));
await p.context().close();

// ---- admin: re-authentication + 30 s auto-hide + audit log ----
p = await newSession("admin"); await login(p, "admin");
await p.click('[data-testid="eye-aadhaar-1"]'); await p.waitForSelector('[data-testid="reauth-modal"]');
ok("Admin: Aadhaar asks for the password first (value not revealed)", (await p.textContent('[data-testid="val-aadhaar-1"]')) === "XXXX-XXXX-0123");
await p.screenshot({ path: "tests/out/ui_05_reauth_modal.png", clip: { x: 0, y: 0, width: 1280, height: 640 } });
await p.fill('[data-testid="reauth-password"]', "not-my-password"); await p.click('[data-testid="reauth-submit"]');
await p.waitForSelector('[data-testid="reauth-error"]');
ok("Admin: wrong password is rejected and the modal stays open", (await p.textContent('[data-testid="reauth-error"]')).includes("incorrect"));
await p.screenshot({ path: "tests/out/ui_06_reauth_wrong.png", clip: { x: 0, y: 0, width: 1280, height: 640 } });
await p.fill('[data-testid="reauth-password"]', PW.admin); await p.click('[data-testid="reauth-submit"]');
await p.waitForSelector('[data-testid="hide-aadhaar-1"]');
const t0 = Date.now();
ok("Admin: correct password reveals the Aadhaar number", (await p.textContent('[data-testid="val-aadhaar-1"]')) === "234567890123");
await p.click('[data-testid="eye-card_number-2"]'); await p.fill('[data-testid="reauth-password"]', PW.admin); await p.click('[data-testid="reauth-submit"]');
await p.waitForSelector('[data-testid="hide-card_number-2"]');
await p.click('[data-testid="eye-email-3"]'); await p.waitForSelector('[data-testid="hide-email-3"]');
await shot(p, "ui_07_admin_revealed");
const left = await p.textContent('[data-testid="left-aadhaar-1"]');
// wait for the real 30 s auto-hide
await p.waitForFunction(() => document.querySelector('[data-testid="val-aadhaar-1"]')?.textContent === "XXXX-XXXX-0123", null, { timeout: 40000 });
const elapsed = (Date.now() - t0) / 1000;
ok("Admin: value auto-hides after ~30 s", elapsed >= 29 && elapsed <= 33, `${elapsed.toFixed(1)} s after the reveal`);
out.autoHideSeconds = elapsed;
await shot(p, "ui_08_after_autohide");
const domAfter = await p.content();
ok("Admin: raw Aadhaar is removed from the DOM after auto-hide", !domAfter.includes("234567890123"));
await p.click('[data-testid="tab-audit"]'); await p.waitForSelector('[data-testid="audit-table"] tbody tr');
await p.screenshot({ path: "tests/out/ui_09_audit_log.png", clip: { x: 0, y: 0, width: 1280, height: 600 } });
ok("Admin: audit log tab lists events", (await p.locator('[data-testid="audit-table"] tbody tr').count()) >= 6);
await p.context().close();

// ---- storage check: no token in localStorage / sessionStorage ----
p = await newSession("compliance"); await login(p, "compliance");
const st = await p.evaluate(() => ({ ls: Object.keys(localStorage).length, ss: Object.keys(sessionStorage).length, cookie: document.cookie }));
ok("Token is not stored in localStorage, sessionStorage or cookies", st.ls === 0 && st.ss === 0 && st.cookie === "", JSON.stringify(st));
await p.context().close();

// ---- Network evidence: list response (masked) vs anti-pattern response (raw) ----
const insecure = await (await fetch(`${BASE}/api/insecure/customers`)).text();
out.insecureSample = JSON.parse(insecure).slice(0, 1);
// hide-with-CSS demo screenshot: raw data is in the DOM, only visually hidden
const ctx = await browser.newContext({ viewport: { width: 900, height: 300 } }); const pg = await ctx.newPage();
await pg.goto(BASE);
await pg.evaluate(() => { document.body.innerHTML = `<div style="font-family:Arial;padding:16px"><h3>Anti-pattern: hidden with CSS only</h3><table border=1 cellpadding=6 style="border-collapse:collapse"><tr><th>Name</th><th>Aadhaar (looks hidden)</th></tr></table></div>`; });
await pg.evaluate(async (base) => {
  const rows = await (await fetch(base + "/api/insecure/customers")).json();
  const t = document.querySelector("table");
  rows.slice(0, 2).forEach((r) => { t.insertAdjacentHTML("beforeend", `<tr><td>${r.full_name}</td><td style="color:transparent;background:#222">${r.aadhaar}</td></tr>`); });
}, BASE);
await pg.screenshot({ path: "tests/out/ui_10_css_only_antipattern.png" });
out.cssOnlyDomContainsRaw = (await pg.content()).includes("234567890123");
ok("Anti-pattern page: raw Aadhaar is present in the DOM although it looks hidden", out.cssOnlyDomContainsRaw);
await ctx.close();

fs.writeFileSync("tests/out/ui-results.json", JSON.stringify(out, null, 2));
const failed = out.checks.filter((c) => !c.pass).length;
console.log(`\n${out.checks.length - failed} passed, ${failed} failed`);
await browser.close(); srv.kill(); process.exit(failed ? 1 : 0);
