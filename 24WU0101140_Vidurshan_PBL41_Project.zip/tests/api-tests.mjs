import { spawn, execSync } from "child_process";
import fs from "fs";

const PORT = 4201, BASE = `http://localhost:${PORT}`;
process.env.DB_FILE = "data/test.db";
execSync("node server/seed.js", { env: { ...process.env, DB_FILE: "data/test.db" }, stdio: "ignore" });
const srv = spawn("node", ["server/index.js"], { env: { ...process.env, PORT, DB_FILE: "data/test.db", ALLOW_INSECURE_DEMO: "1" }, stdio: "ignore" });
await new Promise((r) => setTimeout(r, 1200));

const PW = { admin: "Admin@Pbl41", compliance: "Comply@Pbl41", support: "Support@Pbl41", viewer: "Viewer@Pbl41" };
const FIELDS = ["email", "phone", "pan", "aadhaar", "card_number"];
const REAUTH = new Set(["aadhaar", "card_number"]);
const req = async (path, { token, method = "GET", body } = {}) => {
  const r = await fetch(BASE + path, { method, headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const text = await r.text(); let json = null; try { json = JSON.parse(text); } catch {}
  return { status: r.status, json, text };
};
const tokens = {};
for (const role of Object.keys(PW)) tokens[role] = (await req("/api/login", { method: "POST", body: { username: role, password: PW[role] } })).json.token;

const results = []; let pass = 0, fail = 0;
const check = (id, name, ok, detail = "") => { results.push({ id, name, ok, detail }); ok ? pass++ : fail++; console.log(`${ok ? "PASS" : "FAIL"}  ${id}  ${name} ${detail}`); };

// T1 login
const bad = await req("/api/login", { method: "POST", body: { username: "admin", password: "wrong" } });
check("T1", "Wrong password is rejected on login", bad.status === 401, `(HTTP ${bad.status})`);
const noAuth = await req("/api/customers");
check("T2", "Customer list without a token is rejected", noAuth.status === 401, `(HTTP ${noAuth.status})`);

// T3 raw data never in list response, for every role
const RAW = ["ravi.kumar@gmail.com", "9876543210", "ABCDE1234F", "234567890123", "4111 1111 1111 1111", "4111111111111111"];
let leak = false; const listBodies = {};
for (const role of Object.keys(PW)) {
  const r = await req("/api/customers", { token: tokens[role] }); listBodies[role] = r.text;
  if (RAW.some((x) => r.text.includes(x))) leak = true;
}
check("T3", "No raw PII appears in /api/customers for any role (4 responses scanned)", !leak);
const first = JSON.parse(listBodies.admin)[0];
check("T4", "Masked formats are correct (email, phone, PAN, Aadhaar, card)",
  first.email === "r****@gmail.com" && first.phone === "XXXXXX3210" && first.pan === "XXXXXX234F" && first.aadhaar === "XXXX-XXXX-0123" && first.card_number === "XXXX-XXXX-XXXX-1111",
  JSON.stringify({ email: first.email, phone: first.phone, pan: first.pan, aadhaar: first.aadhaar, card: first.card_number }));

// T5 full role x field matrix (customer 1). Highly sensitive fields use the right password.
const matrix = {}; let matrixOk = true;
for (const role of Object.keys(PW)) {
  matrix[role] = {};
  for (const f of FIELDS) {
    const allowed = { admin: FIELDS, compliance: ["email", "phone", "pan", "aadhaar"], support: ["email", "phone"], viewer: [] }[role].includes(f);
    const r = await req("/api/customers/1/reveal", { token: tokens[role], method: "POST", body: { field: f, password: REAUTH.has(f) ? PW[role] : undefined } });
    const want = allowed ? 200 : 403;
    if (r.status !== want) matrixOk = false;
    matrix[role][f] = r.status;
  }
}
check("T5", "Role matrix enforced by the server: 20 role/field combinations return the expected 200 or 403", matrixOk, JSON.stringify(matrix));

// T6 re-auth
const noPw = await req("/api/customers/1/reveal", { token: tokens.admin, method: "POST", body: { field: "aadhaar" } });
check("T6", "Aadhaar without password returns 401 reauthRequired", noPw.status === 401 && noPw.json.reauthRequired === true, `(HTTP ${noPw.status})`);
const wrongPw = await req("/api/customers/1/reveal", { token: tokens.admin, method: "POST", body: { field: "aadhaar", password: "nope" } });
check("T7", "Aadhaar with the wrong password returns 401", wrongPw.status === 401, `(HTTP ${wrongPw.status})`);
const okPw = await req("/api/customers/1/reveal", { token: tokens.admin, method: "POST", body: { field: "aadhaar", password: PW.admin } });
check("T8", "Aadhaar with the correct password returns the value for 30 s", okPw.status === 200 && okPw.json.value === "234567890123" && okPw.json.visibleForSeconds === 30);
const emailNoPw = await req("/api/customers/2/reveal", { token: tokens.support, method: "POST", body: { field: "email" } });
check("T9", "Medium-sensitivity field (email) needs no password for an allowed role", emailNoPw.status === 200 && emailNoPw.json.value === "priya.sharma@gmail.com");
const nf = await req("/api/customers/999/reveal", { token: tokens.admin, method: "POST", body: { field: "email" } });
check("T10", "Unknown customer returns 404", nf.status === 404);
const unk = await req("/api/customers/1/reveal", { token: tokens.admin, method: "POST", body: { field: "password_hash" } });
check("T11", "Unknown field name returns 400", unk.status === 400);

// T12 audit access control + content
const aSup = await req("/api/audit", { token: tokens.support });
const aViewer = await req("/api/audit", { token: tokens.viewer });
check("T12", "Support and viewer cannot read the audit log (403)", aSup.status === 403 && aViewer.status === 403);
const aAdm = await req("/api/audit?limit=200", { token: tokens.admin });
const rows = aAdm.json;
const has = (o) => rows.some((r) => Object.entries(o).every(([k, v]) => r[k] === v));
check("T13", "Audit log contains SUCCESS, DENIED and FAILED entries", has({ outcome: "SUCCESS", action: "REVEAL" }) && has({ outcome: "DENIED" }) && has({ outcome: "FAILED", action: "REAUTH" }));
const auditText = aAdm.text;
check("T14", "Audit log never contains a raw value (values are not stored)", !RAW.some((x) => auditText.includes(x)) && !auditText.includes("priya.sharma@gmail.com"));
// Expected audit rows: matrix = 11 REVEAL/SUCCESS + 3 REAUTH/SUCCESS + 9 DENIED = 23;
// then wrong password (1 REAUTH/FAILED), correct password (REAUTH/SUCCESS + REVEAL/SUCCESS = 2), email (1), unknown customer (1), unknown field (1) = 6.
// The "password required" 401 challenge is not an attempt, so it is not logged.  Total = 29.
check("T15", "Audit log has exactly one row per decision (29 expected)", rows.length === 29, `(${rows.length} rows)`);

// anti-pattern contrast
const ins = await req("/api/insecure/customers");
check("T16", "Anti-pattern demo: the insecure endpoint DOES leak raw values (shows why CSS-only hiding fails)", RAW.slice(0, 3).every((x) => ins.text.includes(x)));

fs.writeFileSync("tests/out/api-results.json", JSON.stringify({ pass, fail, results, matrix, audit: rows.slice(0, 40), adminListSample: JSON.parse(listBodies.admin).slice(0, 2), revealSample: okPw.json, deniedSample: (await req("/api/customers/1/reveal", { token: tokens.support, method: "POST", body: { field: "pan" } })).json }, null, 2));
console.log(`\n${pass} passed, ${fail} failed`);
srv.kill(); process.exit(fail ? 1 : 0);
