import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { db } from "./db.js";
import { createSession, destroySession, requireAuth, verifyPassword } from "./auth.js";
import { maskCustomer, SENSITIVE_FIELDS } from "./mask.js";
import { canReveal, needsReauth, permissionsFor, CAN_VIEW_AUDIT, REVEAL_SECONDS, FIELD_POLICY } from "./policy.js";

const app = express();
app.use(express.json());
const ip = (req) => req.socket.remoteAddress;

function audit(req, { customerId = null, field = null, action, outcome, detail = null }) {
  db.prepare(`INSERT INTO audit_log(ts,user_id,username,role,customer_id,field,action,outcome,detail,ip) VALUES (?,?,?,?,?,?,?,?,?,?)`)
    .run(new Date().toISOString(), req.user?.id ?? null, req.user?.username ?? "anonymous", req.user?.role ?? "none", customerId, field, action, outcome, detail, ip(req));
}

// ---------- authentication ----------
app.post("/api/login", (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare("SELECT * FROM users WHERE username = ?").get(String(username || ""));
  if (!u || !verifyPassword(String(password || ""), u.salt, u.password_hash)) return res.status(401).json({ error: "Invalid username or password" });
  const user = { id: u.id, username: u.username, display_name: u.display_name, role: u.role };
  res.json({ token: createSession(user), user, permissions: permissionsFor(u.role), canViewAudit: CAN_VIEW_AUDIT.includes(u.role), revealSeconds: REVEAL_SECONDS, fields: FIELD_POLICY });
});
app.post("/api/logout", requireAuth, (req, res) => { destroySession(req.token); res.json({ ok: true }); });

// ---------- masked data (the ONLY customer data the list endpoints ever send) ----------
app.get("/api/customers", requireAuth, (req, res) => {
  const rows = db.prepare("SELECT * FROM customers ORDER BY id").all();
  res.set("Cache-Control", "no-store").json(rows.map(maskCustomer));
});

// ---------- reveal one field of one customer ----------
app.post("/api/customers/:id/reveal", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const { field, password } = req.body || {};
  const base = { customerId: id, field: String(field) };

  if (!SENSITIVE_FIELDS.includes(field)) { audit(req, { ...base, action: "REVEAL", outcome: "BAD_REQUEST", detail: "unknown field" }); return res.status(400).json({ error: "Unknown field" }); }
  if (!canReveal(req.user.role, field)) { audit(req, { ...base, action: "REVEAL", outcome: "DENIED", detail: `role ${req.user.role} not allowed` }); return res.status(403).json({ error: `Role '${req.user.role}' cannot reveal ${FIELD_POLICY[field].label}` }); }

  if (needsReauth(field)) {
    const u = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
    if (!password) return res.status(401).json({ error: "Re-authentication required", reauthRequired: true });
    if (!verifyPassword(String(password), u.salt, u.password_hash)) {
      audit(req, { ...base, action: "REAUTH", outcome: "FAILED", detail: "wrong password" });
      return res.status(401).json({ error: "Password incorrect", reauthRequired: true });
    }
    audit(req, { ...base, action: "REAUTH", outcome: "SUCCESS" });
  }

  const row = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
  if (!row) { audit(req, { ...base, action: "REVEAL", outcome: "NOT_FOUND" }); return res.status(404).json({ error: "Customer not found" }); }

  audit(req, { ...base, action: "REVEAL", outcome: "SUCCESS", detail: `visible for ${REVEAL_SECONDS}s` });
  res.set("Cache-Control", "no-store").json({ id, field, value: row[field], visibleForSeconds: REVEAL_SECONDS });
});

// ---------- audit log (admin + compliance only) ----------
app.get("/api/audit", requireAuth, (req, res) => {
  if (!CAN_VIEW_AUDIT.includes(req.user.role)) return res.status(403).json({ error: "Audit log is restricted" });
  const limit = Math.min(Number(req.query.limit) || 50, 200);
  res.set("Cache-Control", "no-store").json(db.prepare("SELECT id, ts, username, role, customer_id, field, action, outcome, detail FROM audit_log ORDER BY id DESC LIMIT ?").all(limit));
});

// ---------- ANTI-PATTERN, for the report only: sends raw data and hides it with CSS in the browser ----------
if (process.env.ALLOW_INSECURE_DEMO === "1") {
  app.get("/api/insecure/customers", (_req, res) => res.json(db.prepare("SELECT id, full_name, email, phone, pan, aadhaar, card_number FROM customers").all()));
}

app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "dist")));
const PORT = process.env.PORT || 4200;
app.listen(PORT, () => console.log(`PBL 41 API + app on http://localhost:${PORT}`));
