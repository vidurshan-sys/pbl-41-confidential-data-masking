import { db } from "./db.js";
import { hashPassword } from "./auth.js";

// ALL DATA BELOW IS SYNTHETIC TEST DATA (fake names, card numbers are public test numbers).
db.exec("DELETE FROM audit_log; DELETE FROM customers; DELETE FROM users;");

const users = [
  ["admin",      "Anita Admin",       "admin",      "Admin@Pbl41"],
  ["compliance", "Chandru Compliance","compliance", "Comply@Pbl41"],
  ["support",    "Sana Support",      "support",    "Support@Pbl41"],
  ["viewer",     "Vikram Viewer",     "viewer",     "Viewer@Pbl41"],
];
const insU = db.prepare("INSERT INTO users(username, display_name, role, salt, password_hash) VALUES (?,?,?,?,?)");
for (const [u, n, r, p] of users) { const { salt, hash } = hashPassword(p); insU.run(u, n, r, salt, hash); }

const customers = [
  ["Ravi Kumar",     "ravi.kumar@gmail.com",    "9876543210", "ABCDE1234F", "234567890123", "4111 1111 1111 1111", "Namakkal"],
  ["Priya Sharma",   "priya.sharma@gmail.com",  "9123456780", "BCDEF2345G", "345678901234", "5555 5555 5555 4444", "Chennai"],
  ["Arjun Reddy",    "arjun.reddy@outlook.com", "9988776655", "CDEFG3456H", "456789012345", "3782 822463 10005",   "Hyderabad"],
  ["Meena Iyer",     "meena.iyer@gmail.com",    "9445566778", "DEFGH4567J", "567890123456", "6011 1111 1111 1117", "Coimbatore"],
  ["Karthik Raj",    "karthik.raj@yahoo.com",   "9090909090", "EFGHJ5678K", "678901234567", "3056 9309 0259 04",   "Salem"],
  ["Divya Nair",     "divya.nair@gmail.com",    "9345678901", "FGHJK6789L", "789012345678", "4012 8888 8888 1881", "Kochi"],
  ["Sanjay Patel",   "sanjay.patel@gmail.com",  "9811122233", "GHJKL7890M", "890123456789", "5105 1051 0510 5100", "Ahmedabad"],
  ["Lakshmi Menon",  "lakshmi.menon@gmail.com", "9700011122", "HJKLM8901N", "901234567890", "4222 2222 2222 2",   "Madurai"],
];
const insC = db.prepare("INSERT INTO customers(full_name,email,phone,pan,aadhaar,card_number,city) VALUES (?,?,?,?,?,?,?)");
for (const c of customers) insC.run(...c);
console.log(`Seeded ${users.length} users and ${customers.length} synthetic customers.`);
