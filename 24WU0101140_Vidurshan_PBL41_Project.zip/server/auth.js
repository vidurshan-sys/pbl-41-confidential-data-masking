import crypto from "crypto";

export const hashPassword = (password, salt = crypto.randomBytes(16).toString("hex")) => ({
  salt, hash: crypto.scryptSync(password, salt, 32).toString("hex"),
});
export const verifyPassword = (password, salt, hash) => {
  const a = Buffer.from(crypto.scryptSync(password, salt, 32).toString("hex"));
  const b = Buffer.from(hash);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};

// Opaque session tokens kept in server memory (the browser keeps the token in memory too, not in localStorage)
const SESSIONS = new Map();
const SESSION_MS = 30 * 60 * 1000;
export function createSession(user) {
  const token = crypto.randomBytes(32).toString("hex");
  SESSIONS.set(token, { user, exp: Date.now() + SESSION_MS });
  return token;
}
export const destroySession = (token) => SESSIONS.delete(token);
export function requireAuth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer /, "");
  const s = SESSIONS.get(token);
  if (!s || s.exp < Date.now()) return res.status(401).json({ error: "Not authenticated" });
  req.user = s.user; req.token = token; next();
}
