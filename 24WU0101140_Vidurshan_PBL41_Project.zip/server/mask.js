// Server-side masking. The browser NEVER receives the raw value from the list endpoints.
export const maskEmail = (v) => {
  const [user, domain] = v.split("@");
  return `${user[0]}****@${domain}`;
};
export const maskPhone = (v) => "X".repeat(Math.max(v.length - 4, 0)) + v.slice(-4);
export const maskCard = (v) => {
  const digits = v.replace(/\D/g, "");
  return `XXXX-XXXX-XXXX-${digits.slice(-4)}`;
};
export const maskAadhaar = (v) => `XXXX-XXXX-${v.replace(/\D/g, "").slice(-4)}`;
export const maskPan = (v) => "XXXXXX" + v.slice(-4);

export const MASKERS = { email: maskEmail, phone: maskPhone, pan: maskPan, aadhaar: maskAadhaar, card_number: maskCard };
export const SENSITIVE_FIELDS = Object.keys(MASKERS);

export function maskCustomer(row) {
  const out = { id: row.id, full_name: row.full_name, city: row.city };
  for (const f of SENSITIVE_FIELDS) out[f] = MASKERS[f](row[f]);
  return out;
}
