// Role matrix: which role may reveal which field, and which fields need re-authentication.
export const FIELD_POLICY = {
  email:       { label: "Email",          sensitivity: "Medium", reauth: false },
  phone:       { label: "Phone",          sensitivity: "Medium", reauth: false },
  pan:         { label: "PAN",            sensitivity: "High",   reauth: false },
  aadhaar:     { label: "Aadhaar",        sensitivity: "High",   reauth: true  },
  card_number: { label: "Card number",    sensitivity: "High",   reauth: true  },
};

export const ROLE_REVEAL = {
  admin:      ["email", "phone", "pan", "aadhaar", "card_number"],
  compliance: ["email", "phone", "pan", "aadhaar"],
  support:    ["email", "phone"],
  viewer:     [],
};

export const CAN_VIEW_AUDIT = ["admin", "compliance"];
export const REVEAL_SECONDS = 30;

export const canReveal = (role, field) => (ROLE_REVEAL[role] || []).includes(field);
export const needsReauth = (field) => !!FIELD_POLICY[field]?.reauth;

// permission flags sent to the UI so it can draw the right icon (the server still enforces the rule)
export function permissionsFor(role) {
  const out = {};
  for (const f of Object.keys(FIELD_POLICY)) out[f] = { allowed: canReveal(role, f), reauth: needsReauth(f) };
  return out;
}
