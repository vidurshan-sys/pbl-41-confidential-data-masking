import json, subprocess, textwrap
from PIL import Image, ImageDraw, ImageFont
R = "/home/claude/pbl41"; A = f"{R}/docgen/assets"
import os; os.makedirs(A, exist_ok=True)
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"; MONOB = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
ui = json.load(open(f"{R}/tests/out/ui-results.json")); api = json.load(open(f"{R}/tests/out/api-results.json"))

# ---------------- diagrams ----------------
arch = '''digraph G { rankdir=TB; nodesep=0.35; ranksep=0.55; bgcolor="white";
 node [shape=box, style="rounded,filled", fillcolor="#E8EEF7", color="#1F3864", fontname="Helvetica", fontsize=15, margin="0.2,0.12"];
 edge [fontname="Helvetica", fontsize=12, color="#475569"];
 ui [label="React UI (browser)\\nshows masked values only; session token kept in memory", fillcolor="#F1F5F9"];
 subgraph cluster_api { label="Express API (server side)"; fontname="Helvetica-Bold"; fontsize=15; color="#94A3B8"; style=rounded;
   {rank=same; auth [label="Authentication\\nscrypt check,\\nsession token"]; mask [label="Masking module\\nemail, phone, PAN,\\nAadhaar, card"]; rbac [label="RBAC policy\\nrole x field matrix"];}
   audit [label="Audit writer\\none row per decision", fillcolor="#FFF4D6", color="#C27C00"]; }
 db [label="SQLite database\\ncustomers (raw values), users (hashed passwords), audit_log", fillcolor="#E8F5E9", color="#2E7D32"];
 ui -> auth [label=" POST /api/login"]; ui -> mask [label=" GET /api/customers (masked)"]; ui -> rbac [label=" POST .../reveal"];
 rbac -> auth [style=dashed, label=" re-auth", constraint=false]; rbac -> audit; mask -> db; rbac -> db; audit -> db;
}'''
flow = '''digraph F { rankdir=TB; bgcolor="white";
 node [shape=box, style="rounded,filled", fillcolor="#E8EEF7", color="#1F3864", fontname="Helvetica", fontsize=11, margin="0.14,0.07"];
 edge [fontname="Helvetica", fontsize=10, color="#475569"];
 s [label="User clicks the eye icon", fillcolor="#F1F5F9"];
 a [label="POST /api/customers/:id/reveal {field}"];
 q1 [label="Valid session?", shape=diamond, style=filled, fillcolor="#FFF4D6", color="#C27C00"];
 q2 [label="Role allowed\\nto reveal this field?", shape=diamond, style=filled, fillcolor="#FFF4D6", color="#C27C00"];
 q3 [label="Highly sensitive\\n(Aadhaar, card)?", shape=diamond, style=filled, fillcolor="#FFF4D6", color="#C27C00"];
 q4 [label="Password correct?", shape=diamond, style=filled, fillcolor="#FFF4D6", color="#C27C00"];
 e401 [label="401 Not authenticated", fillcolor="#FDECEA", color="#C62828"];
 e403 [label="403 Forbidden\\naudit: DENIED", fillcolor="#FDECEA", color="#C62828"];
 ch [label="401 reauthRequired\\n(UI shows password modal)", fillcolor="#FFF0D6", color="#8A5A00"];
 ef [label="401 Password incorrect\\naudit: REAUTH / FAILED", fillcolor="#FDECEA", color="#C62828"];
 ok [label="Audit: REVEAL / SUCCESS\\n200 {value, visibleForSeconds: 30}\\nCache-Control: no-store", fillcolor="#E8F5E9", color="#2E7D32"];
 t [label="UI shows value + 30 s countdown,\\nthen masks it again and\\ndrops it from the DOM"];
 s -> a -> q1; q1 -> e401 [label="no"]; q1 -> q2 [label="yes"]; q2 -> e403 [label="no"]; q2 -> q3 [label="yes"];
 q3 -> ok [label="no"]; q3 -> q4 [label="yes"]; q4 -> ch [label="not sent"]; q4 -> ef [label="no"]; q4 -> ok [label="yes"]; ok -> t;
}'''
for n, d in (("arch", arch), ("flow", flow)):
    open(f"{A}/{n}.dot", "w").write(d)
    subprocess.run(["dot", "-Tpng", "-Gdpi=170", f"{A}/{n}.dot", "-o", f"{A}/{n}.png"], check=True)

# ---------------- network-evidence images ----------------
def term(lines, title, out, cols=104):
    f = ImageFont.truetype(MONO, 16); fb = ImageFont.truetype(MONOB, 18); cw = f.getbbox("M")[2]
    wr = []
    for l in lines:
        t = l if isinstance(l, tuple) else (l, None)
        s = t[0]; chunks = textwrap.wrap(s, cols, subsequent_indent="    ", drop_whitespace=False) or [""]
        wr += [(c, t[1]) for c in chunks]
    W = 40 + cols * cw; H = 72 + len(wr) * 25 + 16
    im = Image.new("RGB", (W, H), (10, 14, 24)); d = ImageDraw.Draw(im)
    d.text((20, 16), title, font=fb, fill=(255, 255, 255)); y = 54
    for s, col in wr:
        if col is None:
            col = (125, 211, 252) if s.startswith(("GET", "POST", "Request", "Response", "Scan")) else (226, 232, 240)
        d.text((20, y), s, font=f, fill=col); y += 25
    im.save(f"{A}/{out}.png")

G, Rr, Y = (134, 239, 172), (252, 165, 165), (250, 204, 21)
lst = next(n for n in ui["network"] if n["role"] == "support" and n["path"] == "/api/customers")
body = json.loads(lst["body"])
term(["Request   GET /api/customers   (role: support)", "          Authorization: Bearer ********(redacted)", f"Response  {lst['status']} OK   Cache-Control: no-store",
      ("[", None)] + [(f"  {json.dumps(r)}", None) for r in body[:2]] + [("  ... (8 customers, every sensitive field masked)", None), ("]", None), "",
      ("Scan of 4 responses (admin, compliance, support, viewer) for 6 raw test values:", Y),
      ("  ravi.kumar@gmail.com  9876543210  ABCDE1234F  234567890123  4111 1111 1111 1111  4111111111111111", None),
      ("  matches found: 0   (test T3 PASS)", G)], "Network evidence 1: list response contains masked values only", "net_list", 112)

rv = next(n for n in ui["network"] if n["role"] == "support" and n["path"].endswith("/reveal") and n["status"] == 200)
term(["Request   POST /api/customers/1/reveal   (role: support)", f"          body: {rv['reqBody']}", f"Response  {rv['status']} OK   Cache-Control: no-store", f"          {rv['body']}", "",
      ("One field, one customer, only because the role is allowed. The value is returned for", None), ("this click only, the UI hides it after 30 s, and the audit log records the reveal.", None)],
     "Network evidence 2: a successful reveal returns exactly one value", "net_reveal", 100)

den = api["deniedSample"]
term(["Request   POST /api/customers/1/reveal   (role: support)", '          body: {"field":"pan"}', ("Response  403 Forbidden", Rr), f"          {json.dumps(den)}", "",
      ("Request   POST /api/customers/1/reveal   (role: admin, field: aadhaar, no password)", None), ("Response  401 Unauthorized", Y), '          {"error":"Re-authentication required","reauthRequired":true}', "",
      ("Request   POST /api/customers/1/reveal   (role: admin, field: aadhaar, wrong password)", None), ("Response  401 Unauthorized", Y), '          {"error":"Password incorrect","reauthRequired":true}'],
     "Network evidence 3: the server refuses what the UI hides", "net_denied", 100)

ins = ui["insecureSample"][0]
term(["Request   GET /api/insecure/customers    (anti-pattern endpoint, demo only)", "Response  200 OK", ("[", None), (f"  {json.dumps(ins)}", Rr), ("  ...", None), ("]", None), "",
      ("The raw Aadhaar, PAN and card numbers are in the response body. Hiding them with CSS", Rr), ("only changes how they look; anyone can read them in the Network tab or the DOM.", Rr)],
     "Network evidence 4: anti-pattern - raw data sent, hidden only by CSS", "net_insecure", 100)
print("assets ok")
