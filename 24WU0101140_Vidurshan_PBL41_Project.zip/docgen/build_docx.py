import json, re, subprocess, sys, os
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

R = "/home/claude/pbl41"; A = f"{R}/docgen/assets"; T = f"{R}/tests/out"
GH_USER = os.environ.get("GH_USER", "YOUR-GITHUB-USERNAME")
REPO = "pbl-41-confidential-data-masking"
GH_URL = f"https://github.com/{GH_USER}/{REPO}"
OUT = "/home/claude/pbl41/docgen/24WU0101140_Vidurshan_PBL.docx"
NAVY = RGBColor(0x1F, 0x38, 0x64)
api = json.load(open(f"{T}/api-results.json")); ui = json.load(open(f"{T}/ui-results.json"))

def build(pages):
    d = Document()
    s = d.sections[0]
    s.page_width, s.page_height = Inches(8.27), Inches(11.69)
    s.left_margin = s.right_margin = Inches(1.0); s.top_margin = Inches(0.95); s.bottom_margin = Inches(0.9)
    # ---- base styles ----
    st = d.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(11)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.paragraph_format.space_after = Pt(6); st.paragraph_format.line_spacing = 1.15
    for name, size in (("Heading 1", 15), ("Heading 2", 13)):
        h = d.styles[name]; h.font.name = "Times New Roman"; h.font.size = Pt(size); h.font.bold = True; h.font.color.rgb = NAVY
        h.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman"); h.element.rPr.rFonts.set(qn("w:ascii"), "Times New Roman"); h.element.rPr.rFonts.set(qn("w:hAnsi"), "Times New Roman")
        h.paragraph_format.space_before = Pt(14 if name == "Heading 1" else 10); h.paragraph_format.space_after = Pt(5); h.paragraph_format.keep_with_next = True

    def shade(cell, hexcolor):
        tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd")
        sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), hexcolor); tcPr.append(sh)
    def borders(tbl, color="9AA7C0"):
        tblPr = tbl._tbl.tblPr; b = OxmlElement("w:tblBorders")
        for e in ("top", "left", "bottom", "right", "insideH", "insideV"):
            x = OxmlElement(f"w:{e}"); x.set(qn("w:val"), "single"); x.set(qn("w:sz"), "4"); x.set(qn("w:color"), color); b.append(x)
        tblPr.append(b)
    def fixed(tbl, widths):
        lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tbl._tbl.tblPr.append(lay)
        for j, w in enumerate(widths): tbl.columns[j].width = Inches(w)
    def cell_pad(tbl):
        tblPr = tbl._tbl.tblPr; m = OxmlElement("w:tblCellMar")
        for e, v in (("top", 50), ("left", 90), ("bottom", 50), ("right", 90)):
            x = OxmlElement(f"w:{e}"); x.set(qn("w:w"), str(v)); x.set(qn("w:type"), "dxa"); m.append(x)
        tblPr.append(m)
    def runs(p, text, size=None, color=None, italic=False):
        for i, part in enumerate(re.split(r"\*\*(.+?)\*\*", text)):
            if not part: continue
            r = p.add_run(part); r.bold = (i % 2 == 1); r.italic = italic
            if size: r.font.size = Pt(size)
            if color: r.font.color.rgb = color
    def para(text, align=None, size=None, italic=False, after=None, color=None):
        p = d.add_paragraph(); runs(p, text, size, color, italic)
        if align: p.alignment = align
        if after is not None: p.paragraph_format.space_after = Pt(after)
        return p
    def bullet(text):
        p = d.add_paragraph(style="List Bullet"); runs(p, text); p.paragraph_format.space_after = Pt(3); return p
    def numbered(text):
        p = d.add_paragraph(style="List Number"); runs(p, text); p.paragraph_format.space_after = Pt(3); return p
    heads = []
    def H1(t): heads.append((1, t)); return d.add_heading(t, 1)
    def H2(t): heads.append((2, t)); return d.add_heading(t, 2)
    def table(rows, widths, first_bold=True, size=9.5, header=True, align_center=()):
        t = d.add_table(rows=len(rows), cols=len(rows[0])); t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = False
        borders(t); cell_pad(t); fixed(t, widths)
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                c = t.cell(i, j); c.width = Inches(widths[j]); c.text = ""
                p = c.paragraphs[0]; p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
                if header and i == 0:
                    shade(c, "1F3864"); r = p.add_run(str(val)); r.bold = True; r.font.size = Pt(size); r.font.color.rgb = RGBColor(255, 255, 255)
                else:
                    if j == 0 and first_bold: shade(c, "E8EEF7")
                    runs(p, str(val), size)
                    if j == 0 and first_bold:
                        for r in p.runs: r.bold = True
                if j in align_center: p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if header:
            trPr = t.rows[0]._tr.get_or_add_trPr(); h = OxmlElement("w:tblHeader"); h.set(qn("w:val"), "true"); trPr.append(h)
        for row in t.rows:
            trPr = row._tr.get_or_add_trPr(); cs = OxmlElement("w:cantSplit"); cs.set(qn("w:val"), "true"); trPr.append(cs)
        d.add_paragraph().paragraph_format.space_after = Pt(2)
        return t
    figs = [0]
    def figure(path, caption, width=6.1):
        p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.keep_with_next = True; p.paragraph_format.space_after = Pt(2)
        p.add_run().add_picture(path, width=Inches(width))
        figs[0] += 1
        c = d.add_paragraph(); c.alignment = WD_ALIGN_PARAGRAPH.CENTER; r = c.add_run(f"Figure {figs[0]}: {caption}"); r.bold = True; r.font.size = Pt(10)
        c.paragraph_format.space_after = Pt(10)
    def field(run, code):
        for t_, txt in (("begin", None), (None, code), ("end", None)):
            if t_:
                e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), t_); run._r.append(e)
            else:
                e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = txt; run._r.append(e)
    # ---- header / footer ----
    hp = s.header.paragraphs[0]; hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = hp.add_run("Woxsen University | Industry SDLC PBL #41 | 24WU0101140"); r.font.size = Pt(9); r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    fp = s.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run("Page "); r.font.size = Pt(9); r2 = fp.add_run(); r2.font.size = Pt(9); field(r2, "PAGE")

    # ================= COVER =================
    para("**WOXSEN UNIVERSITY**", WD_ALIGN_PARAGRAPH.CENTER, 20, color=NAVY, after=0).paragraph_format.space_before = Pt(30)
    para("Hyderabad, Telangana", WD_ALIGN_PARAGRAPH.CENTER, 11, after=22)
    para("**INDUSTRY SDLC PBL #41**", WD_ALIGN_PARAGRAPH.CENTER, 12, after=4)
    para("**Show/Hide Confidential User Information in the UI**", WD_ALIGN_PARAGRAPH.CENTER, 20, color=NAVY, after=4)
    para("Server-side masking, role-based reveal, password re-authentication, 30-second auto-hide and an audit log for confidential customer data in a React and Node.js application",
         WD_ALIGN_PARAGRAPH.CENTER, 11.5, italic=True, after=22)
    rows = [["SUBMISSION DETAILS", ""], ["Student Name", "Vidurshan S"], ["Roll Number", "24WU0101140"], ["Programme", "B.Tech Computer Science and Engineering (CSE)"],
            ["Section", "Panthers"], ["University", "Woxsen University, Hyderabad"], ["Course Component", "Industry SDLC Project-Based Learning (PBL) #41"],
            ["Tools Used", "React, Node.js (Express), role-based access control (RBAC), audit log table, SQLite"],
            ["GitHub Repository", GH_URL], ["Date of Submission", "8 October 2026"], ["Signature", ""]]
    t = d.add_table(rows=len(rows), cols=2); t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = False; borders(t, "1F3864"); cell_pad(t); fixed(t, [1.9, 4.3])
    for i, (a, b) in enumerate(rows):
        c0, c1 = t.cell(i, 0), t.cell(i, 1); c0.width = Inches(1.9); c1.width = Inches(4.3)
        if i == 0:
            m = c0.merge(c1); shade(m, "1F3864"); m.text = ""; p = m.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = p.add_run(a); r.bold = True; r.font.color.rgb = RGBColor(255, 255, 255); r.font.size = Pt(10.5); continue
        shade(c0, "E8EEF7"); c0.text = ""; r = c0.paragraphs[0].add_run(a); r.bold = True; r.font.size = Pt(10.5)
        c1.text = ""; p = c1.paragraphs[0]; r = p.add_run(b); r.font.size = Pt(10.5)
        if a == "GitHub Repository": r.font.color.rgb = RGBColor(0x05, 0x63, 0xC1); r.underline = True
        if a == "Signature":
            for c in (c0, c1): c.paragraphs[0].paragraph_format.space_after = Pt(26)
        for c in (c0, c1): c.paragraphs[0].paragraph_format.space_after = Pt(3 if a != "Signature" else 26)
    d.add_page_break()

    # ================= TOC =================
    p = d.add_paragraph(); r = p.add_run("TABLE OF CONTENTS"); r.bold = True; r.font.size = Pt(14); r.font.color.rgb = NAVY
    toc_anchor = d.add_paragraph()   # entries inserted here later
    d.add_page_break()

    # ================= 1 =================
    H1("1. Introduction")
    H2("1.1 Objective")
    para("The objective of this assignment is to build a feature in which confidential customer information (card number, Aadhaar, PAN, phone number and email address) is displayed **masked by default** in a React interface. A user can reveal a value with an eye icon only if their role allows it; highly sensitive fields additionally require **re-authentication**; a revealed value **hides again automatically after 30 seconds**; and **every reveal attempt is written to an audit table**. The masking has to be done **on the server**, so that unmasked data never reaches the browser unless a reveal has been approved.")
    H2("1.2 Scope")
    para("The work covers the web client and the REST API of a small Customer Data Console with four roles (admin, compliance, support, viewer), five confidential fields and eight customers. All customer data in this project is synthetic: names are invented and the card numbers are publicly documented test numbers. For re-authentication the user's own password is requested; a one-time password (OTP) was not implemented, and the assignment accepts either. Every result in this document comes from automated tests that were actually run (Section 7).")
    H2("1.3 Application and Environment")
    table([["Item", "Details"],
           ["Frontend", "React 18 with Vite 5; plain fetch calls; the session token is kept only in memory (not in localStorage, sessionStorage or cookies)"],
           ["Backend", "Node.js 22 with Express 4; SQLite through the built-in node:sqlite module; central masking, policy and audit modules"],
           ["Authentication", "Passwords stored as salted scrypt hashes; opaque random session tokens that expire after 30 minutes; constant-time hash comparison"],
           ["Authorisation", "Role-based access control; a role-by-field matrix enforced by the server; the UI only mirrors it"],
           ["Test tools", "Node.js test scripts (16 API checks) and Playwright with headless Chromium (15 browser checks and all screenshots)"],
           ["Test data", "8 synthetic customers and 4 seeded accounts, one per role; no real personal data"]], [1.5, 4.7])

    # ================= 2 =================
    H1("2. Design Approach")
    H2("2.1 Masking Rules")
    para("Masking is a pure server-side function. The list endpoint applies it to every sensitive field before the response is built, so the browser never receives the original values from it.")
    table([["Field", "Sensitivity", "Masked format", "Example (raw to masked)"],
           ["Email", "Medium", "first letter + **** + domain", "ravi.kumar@gmail.com to r****@gmail.com"],
           ["Phone", "Medium", "X for all but the last 4 digits", "9876543210 to XXXXXX3210"],
           ["PAN", "High", "XXXXXX + last 4 characters", "ABCDE1234F to XXXXXX234F"],
           ["Aadhaar", "High (password)", "XXXX-XXXX- + last 4 digits", "234567890123 to XXXX-XXXX-0123"],
           ["Card number", "High (password)", "XXXX-XXXX-XXXX- + last 4 digits", "4111 1111 1111 1111 to XXXX-XXXX-XXXX-1111"]], [1.0, 1.1, 2.0, 2.1])
    H2("2.2 Role-Based Access Control")
    para("The role matrix is defined once on the server (policy module). A request to reveal a field is allowed only if the role appears in the matrix; otherwise the server answers 403 and writes a DENIED row to the audit log.")
    table([["Role", "Email", "Phone", "PAN", "Aadhaar", "Card", "Audit log"],
           ["admin", "Reveal", "Reveal", "Reveal", "Reveal + password", "Reveal + password", "Yes"],
           ["compliance", "Reveal", "Reveal", "Reveal", "Reveal + password", "No (403)", "Yes"],
           ["support", "Reveal", "Reveal", "No (403)", "No (403)", "No (403)", "No (403)"],
           ["viewer", "No (403)", "No (403)", "No (403)", "No (403)", "No (403)", "No (403)"]], [0.95, 0.75, 0.75, 0.75, 1.1, 1.1, 0.8], size=9, align_center=(1, 2, 3, 4, 5, 6))
    H2("2.3 Re-authentication and Auto-hide")
    bullet("**Re-authentication:** Aadhaar and card numbers are classed as highly sensitive. The first reveal request without a password is answered with 401 and reauthRequired; the UI then opens a modal asking the user to confirm their own password. A wrong password returns 401 and is logged as REAUTH / FAILED; a correct one is logged as REAUTH / SUCCESS and the value is returned.")
    bullet("**Auto-hide:** the reveal response contains visibleForSeconds = 30. The UI shows a countdown beside the value, hides it when the countdown ends (or when the user presses Hide) and removes it from the DOM. Responses carry Cache-Control: no-store so the value is not kept by the browser cache.")
    bullet("**No raw values in the audit log:** the log stores who, when, which customer and field, and the outcome, never the revealed value.")
    H2("2.4 Audit Log Design")
    table([["Column", "Meaning"],
           ["ts, ip", "UTC timestamp of the decision and the client address"],
           ["username, role, user_id", "Who made the request (anonymous if there was no session)"],
           ["customer_id, field", "Which customer record and which field was requested"],
           ["action", "REVEAL (reveal decision) or REAUTH (password confirmation)"],
           ["outcome", "SUCCESS, DENIED, FAILED, NOT_FOUND or BAD_REQUEST"],
           ["detail", "Short reason, for example: role support not allowed; visible for 30s"]], [1.8, 4.4])
    H2("2.5 Architecture and Request Flow")
    figure(f"{A}/arch.png", "Architecture: masking, RBAC, authentication and audit are all on the server", 6.0)
    figure(f"{A}/flow.png", "Request flow for revealing one field", 5.0)

    # ================= 3 =================
    H1("3. Implementation and Evidence")
    para("All figures in this section are screenshots of the running application, captured in headless Chromium by the Playwright test script (tests/ui-shots.mjs). Section 12 explains exactly what they are and are not.")
    H2("3.1 Sign-in")
    para("The console starts with a sign-in form. A wrong password is rejected with a generic error message and no hint about which part was wrong. No demonstration credentials are printed on the page.")
    figure(f"{T}/ui_01_login.png", "Sign-in page", 3.6)
    H2("3.2 Masked by Default")
    para("After signing in as the support role, every confidential value is masked. The eye icon appears next to email and phone, which this role may reveal, and a lock icon appears next to PAN, Aadhaar and card number, which it may not (the lock buttons are disabled).")
    figure(f"{T}/ui_02_support_masked.png", "Support role: all sensitive fields masked; PAN, Aadhaar and card are locked")
    H2("3.3 Revealing a Value")
    para("Clicking the eye icon calls the reveal endpoint. The value is shown highlighted with a countdown, and the Hide button masks it again immediately.")
    figure(f"{T}/ui_03_support_revealed.png", "Support role: email and phone of the first customer revealed with a 30 s countdown")
    H2("3.4 A Role with No Reveal Rights")
    figure(f"{T}/ui_04_viewer_locked.png", "Viewer role: all 40 sensitive cells are locked")
    H2("3.5 Re-authentication for Highly Sensitive Fields")
    para("For the admin role the Aadhaar and card numbers show a key icon. Clicking it opens a password modal; the value stays masked until the password is confirmed. A wrong password keeps the modal open with an error message.")
    figure(f"{T}/ui_05_reauth_modal.png", "Admin role: password confirmation before revealing an Aadhaar number")
    figure(f"{T}/ui_06_reauth_wrong.png", "A wrong password is rejected and logged as REAUTH / FAILED")
    figure(f"{T}/ui_07_admin_revealed.png", "After the correct password: Aadhaar, a card number and an email are revealed with countdowns")
    H2("3.6 Automatic Hide After 30 Seconds")
    para(f"The browser test measured the time between the reveal and the moment the value became masked again: **{ui['autoHideSeconds']:.1f} seconds**. The test also checked that the raw Aadhaar number was no longer present anywhere in the page DOM afterwards.")
    figure(f"{T}/ui_08_after_autohide.png", "30 s after the reveal: the Aadhaar and card values are masked again")
    H2("3.7 Audit Log View")
    figure(f"{T}/ui_09_audit_log.png", "Audit log tab (admin and compliance only), newest event first")

    # ================= 4 =================
    H1("4. Proof That Masked Data Never Leaves the Server")
    para("The most important requirement is that masking is not a visual effect. Four captured HTTP exchanges show how the server behaves.")
    figure(f"{T.replace('tests/out','docgen/assets')}/net_list.png", "The list response contains only masked values; scanning four responses for six raw values found zero matches", 6.1)
    figure(f"{A}/net_reveal.png", "A reveal returns exactly one value for one customer and is marked no-store", 6.1)
    figure(f"{A}/net_denied.png", "The server refuses a forbidden role (403) and asks for or rejects a password (401)", 6.1)
    para("In addition, the browser test inspected the page source before any reveal: none of the raw test values (email, phone, PAN, Aadhaar, card) was present in the DOM of the support session. After the 30 s auto-hide the revealed Aadhaar was no longer in the DOM either.")
    H2("4.1 Contrast: the Common Anti-pattern")
    para("A frequent security finding is data that is only hidden with CSS or JavaScript. To show the difference, a deliberately insecure endpoint (disabled unless ALLOW_INSECURE_DEMO=1, never enabled in normal use) returns the raw values. A page built on it can make the Aadhaar column look hidden, yet the raw number is in the response and in the DOM.")
    figure(f"{A}/net_insecure.png", "Anti-pattern: the raw values are in the response body", 6.1)
    figure(f"{T}/ui_10_css_only_antipattern.png", "Anti-pattern page: the Aadhaar column looks blank, but the raw value is in the DOM (test confirmed)", 4.6)

    # ================= 5 =================
    H1("5. Role Matrix Verified by the Server")
    para("The test script called the reveal endpoint for every role and every field (20 combinations) with the correct password where one is needed, and compared the HTTP status code with the policy. All 20 matched.")
    M = api["matrix"]; lab = {"email": "Email", "phone": "Phone", "pan": "PAN", "aadhaar": "Aadhaar", "card_number": "Card"}
    table([["Role"] + list(lab.values())] + [[r] + [f"{M[r][f]}" + (" OK" if M[r][f] == 200 else " Forbidden") for f in lab] for r in ("admin", "compliance", "support", "viewer")],
          [1.1, 1.0, 1.0, 1.0, 1.0, 1.1], align_center=(1, 2, 3, 4, 5))

    # ================= 6 =================
    H1("6. Audit Log Sample")
    para("The table shows rows read back through GET /api/audit after the role-matrix test, oldest first. Note that denied attempts are recorded as well as successful reveals, and that no value is stored.")
    rows = list(reversed(api["audit"]))
    def pick(f): return next((r for r in rows if f(r)), None)
    chosen = [pick(lambda r: r["role"] == "admin" and r["field"] == "email" and r["outcome"] == "SUCCESS"),
              pick(lambda r: r["role"] == "admin" and r["field"] == "aadhaar" and r["action"] == "REAUTH"),
              pick(lambda r: r["role"] == "admin" and r["field"] == "aadhaar" and r["action"] == "REVEAL"),
              pick(lambda r: r["role"] == "compliance" and r["field"] == "card_number"),
              pick(lambda r: r["role"] == "support" and r["field"] == "pan"),
              pick(lambda r: r["role"] == "viewer" and r["field"] == "email"),
              pick(lambda r: r["outcome"] == "FAILED"),
              pick(lambda r: r["outcome"] == "NOT_FOUND"),
              pick(lambda r: r["outcome"] == "BAD_REQUEST")]
    chosen = sorted([c for c in chosen if c], key=lambda r: r["id"])
    table([["#", "Time (UTC)", "User / role", "Cust.", "Field", "Action", "Outcome", "Detail"]] +
          [[r["id"], r["ts"][11:19], f"{r['username']} / {r['role']}", r["customer_id"], r["field"] or "-", r["action"], r["outcome"], r["detail"] or "-"] for r in chosen],
          [0.35, 0.7, 0.95, 0.4, 0.85, 0.7, 1.1, 1.15], first_bold=False, size=8.5)
    para(f"In total the matrix test produced {len(api['audit'])} audit rows, exactly the number expected: 11 successful reveals, 3 successful and 1 failed password confirmations, 9 denied attempts, 1 reveal after a correct password, 1 email reveal, 1 unknown customer and 1 unknown field.")

    # ================= 7 =================
    H1("7. Test Summary")
    H2("7.1 API Tests (tests/api-tests.mjs)")
    table([["ID", "Test", "Result"]] + [[r["id"], r["name"].split(" {")[0], "Pass" if r["ok"] else "Fail"] for r in api["results"]], [0.5, 5.0, 0.7], first_bold=False, size=9, align_center=(2,))
    H2("7.2 Browser Tests (tests/ui-shots.mjs)")
    table([["No.", "Test", "Result"]] + [[i + 1, c["name"], "Pass" if c["pass"] else "Fail"] for i, c in enumerate(ui["checks"])], [0.5, 5.0, 0.7], first_bold=False, size=9, align_center=(2,))
    para(f"Total: {api['pass']} of {api['pass'] + api['fail']} API checks and {sum(c['pass'] for c in ui['checks'])} of {len(ui['checks'])} browser checks passed.")

    # ================= 8 =================
    H1("8. Verified Controls")
    for t_ in ["Masking happens on the server; the list endpoint never sends a raw value, for any role (scanned in four responses).",
               "Authorisation is enforced by the server: a forbidden reveal returns 403 even though the UI also disables the control.",
               "Highly sensitive fields need the user's password, and a wrong password is logged and rejected.",
               "Revealed values disappear after 30 s and are removed from the DOM; responses are marked no-store.",
               "Every decision (success, denied, failed, not found, bad request) is written to the audit table, and the table never contains the values.",
               "The session token is held in memory only; localStorage, sessionStorage and cookies were empty after sign-in.",
               "Passwords are stored as salted scrypt hashes and compared in constant time; the login error message does not reveal which part was wrong."]:
        bullet(t_)

    # ================= 9 =================
    H1("9. Observations")
    for t_ in ["Putting the policy in one server module (role by field) made the UI simple: the login response tells the UI which icon to draw, but the server decides every request again.",
               "Masking on the server also removed a class of problems: there is nothing to leak through browser extensions, page-source views or the Network tab for fields a user cannot reveal.",
               "The 30 s timer is a client-side convenience. The server cannot take a value back once it has been sent, so the real protections are the role check, the password for the most sensitive fields, no-store headers and the audit trail.",
               "Logging denied attempts is as useful as logging successes: repeated DENIED rows for one user are an early signal of misuse.",
               "The first click on a highly sensitive field intentionally costs one extra 401 round trip, so the UI never has to guess which fields need a password."]:
        bullet(t_)

    # ================= 10-11 =================
    H1("10. Conclusion")
    para("A working feature was built and tested in which confidential customer data is masked by default on the server, revealed per field only to authorised roles, protected by password re-authentication for Aadhaar and card numbers, hidden again after 30 seconds and recorded in an audit table. All 16 API checks and 15 browser checks passed, and the captured responses show that masked data is all the browser receives until a reveal is approved. The remaining improvements are listed in Section 12.")
    H1("11. Industry Lesson")
    para("**Banking and fintech applications mask by default and log every reveal; hiding with CSS alone is a common security finding.** If the browser has received the value, anyone can read it from the response or the DOM. Real protection means the server decides what to send, checks the role on every request, asks for re-authentication for the most sensitive data and keeps an audit trail of who looked at what.")

    # ================= 12 =================
    H1("12. Limitations and Disclosures")
    for t_ in ["The screenshots are real captures of the running application taken in headless Chromium by the Playwright script. They are not Chrome DevTools panel screenshots. The \"network evidence\" figures are text renderings of the HTTP requests and responses captured by the same script (the password is shown as ******** and the session token is redacted). For the final printed copy the author may add genuine Network-tab screenshots by running the app locally.",
               "All data is synthetic. The test accounts and their passwords are for local testing only and are listed in the repository README.",
               "The 30-second hide is enforced in the browser. After a reveal the value has reached the client, which is why the role check, re-authentication, no-store headers and audit logging matter more than the timer.",
               "Re-authentication uses the user's password; OTP was not implemented. There is no lockout or rate limit on repeated wrong passwords, and sessions live in server memory, so a restart signs everyone out. These are the first things to add for production.",
               "Masked formats keep the last four characters, which is common practice but still reveals some information; stricter policies can mask more.",
               "The tests ran in a cloud sandbox with headless Chromium, not on the author's laptop, so timings (for example 30.0 s for the auto-hide) are indicative.",
               f"The GitHub repository link on the cover page points to the repository the author must create and push from the project folder (commands in Appendix A). Until the push is done the link will not open."]:
        bullet(t_)

    # ================= 13 =================
    H1("13. Viva Preparation")
    table([["Question", "Short answer"],
           ["Why mask on the server and not with CSS?", "Anything sent to the browser can be read from the response or the DOM. Server-side masking means the raw value is never sent unless a reveal is approved."],
           ["What does RBAC mean here?", "Each role has a list of fields it may reveal. The server checks it on every request and returns 403 if the role is not listed."],
           ["Why ask for the password again?", "Re-authentication protects against a session left open on an unattended computer and confirms that the person revealing Aadhaar or a card number is the account owner."],
           ["What is logged and what is not?", "User, role, time, customer, field, action and outcome are logged. The revealed value is never stored in the audit table."],
           ["Why 401 for a missing password but 403 for a forbidden role?", "401 means the caller must authenticate (again); 403 means the caller is known but not permitted."],
           ["Can the 30-second auto-hide be bypassed?", "A user could copy the value while it is visible, and the timer is client-side. That is why access is also limited by role, password and audit logging."],
           ["Where is the session token stored and why?", "Only in JavaScript memory. localStorage can be read by injected scripts, and memory is cleared on reload."],
           ["How are passwords stored?", "Salted scrypt hashes, compared with a constant-time function."],
           ["How would you add OTP instead of the password?", "Send a one-time code to the user's registered device, store only its hash with a short expiry and attempt limit, and accept it in the same re-authentication step."]], [2.0, 4.2], size=9.5)

    # ================= Appendix =================
    H1("Appendix A: Repository and Artifacts")
    para(f"**GitHub repository:** {GH_URL}")
    for t_ in ["server/: Express API (index.js), masking (mask.js), role policy (policy.js), authentication (auth.js), SQLite access (db.js), seed data (seed.js).",
               "src/: React application (App.jsx, components for the customer table, the sensitive cell with eye icon and countdown, the password modal and the audit log).",
               "tests/api-tests.mjs and tests/ui-shots.mjs: automated tests and the screenshot script; tests/out/ holds the screenshots and the JSON result files.",
               "docs/role-matrix.md and README.md: role matrix, setup steps and the synthetic test accounts."]:
        bullet(t_)
    para("**How to run:**", after=2)
    for c in ["npm install", "npm run seed", "npm run build", "npm run server      (http://localhost:4200)", "npm run test:api   and   npm run test:ui"]:
        p = d.add_paragraph(); r = p.add_run("    " + c); r.font.name = "Consolas"; r.font.size = Pt(9.5); p.paragraph_format.space_after = Pt(0)
    para("", after=4)
    para("**Test accounts (synthetic, local only):** admin / compliance / support / viewer; the passwords are in README.md.")

    # ---------- TOC entries ----------
    for lvl, text in heads:
        pn = pages.get(text, "")
        p = toc_anchor.insert_paragraph_before()
        p.paragraph_format.tab_stops.add_tab_stop(Inches(6.27), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        p.paragraph_format.space_after = Pt(2 if lvl == 2 else 3); p.paragraph_format.left_indent = Inches(0 if lvl == 1 else 0.25)
        r = p.add_run(f"{text}\t{pn}"); r.bold = (lvl == 1); r.font.size = Pt(10.5 if lvl == 2 else 11)
    toc_anchor._element.getparent().remove(toc_anchor._element)
    d.save(OUT); return heads

heads = build({})
subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", "/tmp/claude-0/pbl", OUT], capture_output=True, timeout=180)
pdf = "/tmp/claude-0/pbl/24WU0101140_Vidurshan_PBL.pdf"
n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout).group(1))
pages = {}
texts = [subprocess.run(["pdftotext", "-f", str(i), "-l", str(i), "-layout", pdf, "-"], capture_output=True, text=True).stdout for i in range(1, n + 1)]
for lvl, h in heads:
    for i in range(3, n + 1):   # skip cover + TOC
        if any(line.strip() == h or line.strip().startswith(h) and len(line.strip()) <= len(h) + 2 for line in texts[i - 1].splitlines()):
            pages[h] = i; break
missing = [h for _, h in heads if h not in pages]
print("pages:", n, "missing:", missing)
build(pages)
subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", "/tmp/claude-0/pbl", OUT], capture_output=True, timeout=180)
print("final pages:", subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.split("Pages:")[1].split()[0])
