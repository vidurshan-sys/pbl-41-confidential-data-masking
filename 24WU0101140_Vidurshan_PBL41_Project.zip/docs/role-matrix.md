# Role matrix (enforced by server/policy.js)

| Role       | Email  | Phone  | PAN    | Aadhaar           | Card              | Audit log |
|------------|--------|--------|--------|-------------------|-------------------|-----------|
| admin      | reveal | reveal | reveal | reveal + password | reveal + password | yes |
| compliance | reveal | reveal | reveal | reveal + password | 403               | yes |
| support    | reveal | reveal | 403    | 403               | 403               | 403 |
| viewer     | 403    | 403    | 403    | 403               | 403               | 403 |

Verified by tests/api-tests.mjs (test T5: all 20 role/field combinations return the expected 200 or 403).
