import React, { useState } from "react";
import { login, logout, setToken } from "./api.js";
import Customers from "./components/Customers.jsx";
import AuditLog from "./components/AuditLog.jsx";

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  async function submit(e) {
    e.preventDefault(); setError("");
    try { const r = await login(username, password); setToken(r.token); onLogin(r); }
    catch (err) { setError(err.message); }
  }
  return (
    <form className="login card" onSubmit={submit}>
      <h1>Customer Data Console</h1>
      <p className="muted">Confidential fields are masked by default.</p>
      <label>Username<input data-testid="username" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="off" /></label>
      <label>Password<input data-testid="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="off" /></label>
      {error && <p className="error" data-testid="login-error">{error}</p>}
      <button data-testid="login-btn" type="submit" className="primary">Sign in</button>
    </form>
  );
}

export default function App() {
  const [session, setSession] = useState(null);
  const [tab, setTab] = useState("customers");

  async function doLogout() { try { await logout(); } catch {} setToken(null); setSession(null); setTab("customers"); }
  if (!session) return <Login onLogin={setSession} />;

  return (
    <div className="shell">
      <header>
        <strong>Customer Data Console</strong>
        <nav>
          <button data-testid="tab-customers" className={tab === "customers" ? "tab on" : "tab"} onClick={() => setTab("customers")}>Customers</button>
          {session.canViewAudit && <button data-testid="tab-audit" className={tab === "audit" ? "tab on" : "tab"} onClick={() => setTab("audit")}>Audit log</button>}
        </nav>
        <span className="who" data-testid="who">{session.user.display_name} <span className={`badge role-${session.user.role}`}>{session.user.role}</span></span>
        <button data-testid="logout" onClick={doLogout}>Sign out</button>
      </header>
      <main>
        {tab === "customers" ? <Customers session={session} /> : <AuditLog />}
      </main>
    </div>
  );
}
