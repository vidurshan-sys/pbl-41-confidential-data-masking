import React, { useState } from "react";

export default function ReauthModal({ label, onCancel, onSubmit }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  async function submit(e) {
    e.preventDefault(); setErr("");
    try { await onSubmit(pw); } catch (ex) { setErr(ex.message); setPw(""); }
  }
  return (
    <div className="overlay">
      <form className="modal card" onSubmit={submit} data-testid="reauth-modal">
        <h3>Confirm your password</h3>
        <p className="muted">{label} is highly sensitive. Re-enter your password to reveal it. This action is logged.</p>
        <input data-testid="reauth-password" type="password" autoFocus value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Your password" />
        {err && <p className="error" data-testid="reauth-error">{err}</p>}
        <div className="row"><button type="button" onClick={onCancel} data-testid="reauth-cancel">Cancel</button><button type="submit" className="primary" data-testid="reauth-submit">Confirm and reveal</button></div>
      </form>
    </div>
  );
}
