import React, { useEffect, useState } from "react";
import { getCustomers } from "../api.js";
import SensitiveCell from "./SensitiveCell.jsx";

const COLS = ["email", "phone", "pan", "aadhaar", "card_number"];

export default function Customers({ session }) {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { getCustomers().then(setRows).catch((e) => setError(e.message)); }, []);
  if (error) return <p className="error">{error}</p>;

  return (
    <div className="card">
      <div className="legend muted">
        <span>👁 reveal</span><span>🔒 not allowed for your role</span><span>🔑 password required</span>
        <span>Revealed values hide again after {session.revealSeconds} s</span>
      </div>
      <table data-testid="customers-table">
        <thead>
          <tr><th>Name</th><th>City</th>{COLS.map((c) => <th key={c}>{session.fields[c].label}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} data-testid={`row-${r.id}`}>
              <td>{r.full_name}</td><td>{r.city}</td>
              {COLS.map((c) => (
                <td key={c}><SensitiveCell customerId={r.id} field={c} masked={r[c]} perm={session.permissions[c]} label={session.fields[c].label} seconds={session.revealSeconds} /></td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
