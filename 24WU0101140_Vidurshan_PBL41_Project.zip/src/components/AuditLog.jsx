import React, { useEffect, useState } from "react";
import { getAudit } from "../api.js";

export default function AuditLog() {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");
  useEffect(() => { getAudit().then(setRows).catch((e) => setError(e.message)); }, []);
  if (error) return <p className="error">{error}</p>;
  return (
    <div className="card">
      <h3>Audit log <small className="muted">(latest 30 events, no raw values are ever stored here)</small></h3>
      <table data-testid="audit-table">
        <thead><tr><th>#</th><th>Time (UTC)</th><th>User</th><th>Role</th><th>Customer</th><th>Field</th><th>Action</th><th>Outcome</th></tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>{r.id}</td><td>{r.ts.replace("T", " ").slice(0, 19)}</td><td>{r.username}</td><td>{r.role}</td>
              <td>{r.customer_id ?? "-"}</td><td>{r.field ?? "-"}</td><td>{r.action}</td>
              <td><span className={`badge out-${r.outcome}`}>{r.outcome}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
