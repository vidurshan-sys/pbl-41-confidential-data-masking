import React, { useEffect, useRef, useState } from "react";
import { reveal } from "../api.js";
import ReauthModal from "./ReauthModal.jsx";

// States: masked -> (optional re-auth) -> revealed (countdown) -> masked again.
export default function SensitiveCell({ customerId, field, masked, perm, label, seconds }) {
  const [value, setValue] = useState(null);
  const [left, setLeft] = useState(0);
  const [askPassword, setAskPassword] = useState(false);
  const [msg, setMsg] = useState("");
  const timer = useRef(null);
  const tid = `${field}-${customerId}`;

  const hide = () => { clearInterval(timer.current); setValue(null); setLeft(0); };
  useEffect(() => () => clearInterval(timer.current), []);

  function startCountdown(v, secs) {
    setValue(v); setLeft(secs); clearInterval(timer.current);
    let n = secs;
    timer.current = setInterval(() => { n -= 1; setLeft(n); if (n <= 0) hide(); }, 1000);
  }

  async function doReveal(password) {
    setMsg("");
    try {
      const r = await reveal(customerId, field, password);
      setAskPassword(false);
      startCountdown(r.value, r.visibleForSeconds);
    } catch (e) {
      if (e.status === 401 && e.body?.reauthRequired) { if (password) throw e; setAskPassword(true); return; }
      setMsg(e.message);
    }
  }

  if (!perm.allowed) {
    return (
      <span className="cell"><span className="val" data-testid={`val-${tid}`}>{masked}</span>
        <button className="icon locked" data-testid={`lock-${tid}`} disabled title={`Your role cannot reveal ${label}`}>🔒</button></span>
    );
  }
  return (
    <span className="cell">
      <span className={value ? "val shown" : "val"} data-testid={`val-${tid}`}>{value ?? masked}</span>
      {value
        ? <button className="icon" data-testid={`hide-${tid}`} onClick={hide} title="Hide now">🙈<small data-testid={`left-${tid}`}>{left}s</small></button>
        : <button className="icon" data-testid={`eye-${tid}`} onClick={() => doReveal()} title={perm.reauth ? `Reveal ${label} (password required)` : `Reveal ${label}`}>{perm.reauth ? "🔑" : "👁"}</button>}
      {msg && <small className="error">{msg}</small>}
      {askPassword && <ReauthModal label={label} onCancel={() => setAskPassword(false)} onSubmit={doReveal} />}
    </span>
  );
}
