// The access token lives only in this module's memory (never localStorage / sessionStorage).
let token = null;
export const setToken = (t) => { token = t; };

async function call(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) { const e = new Error(body.error || `HTTP ${res.status}`); e.status = res.status; e.body = body; throw e; }
  return body;
}
export const login = (username, password) => call("/api/login", { method: "POST", body: JSON.stringify({ username, password }) });
export const logout = () => call("/api/logout", { method: "POST" });
export const getCustomers = () => call("/api/customers");
export const reveal = (id, field, password) => call(`/api/customers/${id}/reveal`, { method: "POST", body: JSON.stringify({ field, password }) });
export const getAudit = () => call("/api/audit?limit=30");
